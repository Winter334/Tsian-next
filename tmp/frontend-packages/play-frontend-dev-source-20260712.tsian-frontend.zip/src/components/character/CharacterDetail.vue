<script setup lang="ts">
/**
 * CharacterDetail — 角色卡右侧详情区（tabs + panes）。
 *
 * design §4.3 / §4.4 / R7：
 * - tab state：overview | attributes | inventory，默认 overview。
 * - tabs：概况 / 属性 / 背包。
 * - 切换 tab 时只换 pane 内容（立绘栏不变，由 CharacterCard 持有）。
 * - active tab 用 --ember 下边框（参考预览 HTML）。
 *
 * props 由 CharacterCard 透传：entity + relationships + displayItems。
 */
import { ref } from "vue"
import type { CharacterEntity, RelationshipFile } from "../../lib/character-types"
import type { DisplayItems } from "../../lib/runtime-types"
import OverviewPane from "./OverviewPane.vue"
import AttributesPane from "./AttributesPane.vue"
import InventoryPane from "./InventoryPane.vue"

const props = defineProps<{
  entity: CharacterEntity
  relationships: RelationshipFile | null
  displayItems: DisplayItems
  /** 主角 ref，透传给 InventoryPane（未来"仅主角可查看"策略）。 */
  protagonistRef: string | null
  /** 当前角色 entity ref（用于 PinButton 构造 target；null 时禁用 pin）。 */
  entityRef: string | null
}>()

const emit = defineEmits<{
  select: [ref: string]
}>()

type Tab = "overview" | "attributes" | "inventory"
const activeTab = ref<Tab>("overview")

function setTab(t: Tab) {
  activeTab.value = t
}

function onSelect(ref: string) {
  emit("select", ref)
}
</script>

<template>
  <div class="detail-column">
    <div class="card-toolbar">
      <div class="card-title-block">
        <div class="card-kicker">CHARACTER DOSSIER</div>
        <div class="card-title">角色档案</div>
      </div>
      <div class="tabs">
        <button
          class="tab"
          :class="{ active: activeTab === 'overview' }"
          type="button"
          @click="setTab('overview')"
        >概况</button>
        <button
          class="tab"
          :class="{ active: activeTab === 'attributes' }"
          type="button"
          @click="setTab('attributes')"
        >属性</button>
        <button
          class="tab"
          :class="{ active: activeTab === 'inventory' }"
          type="button"
          @click="setTab('inventory')"
        >背包</button>
      </div>
    </div>

    <div class="tab-content">
      <Transition name="detail-pane" mode="out-in">
        <OverviewPane
          v-if="activeTab === 'overview'"
          key="overview"
          :entity="entity"
          :relationships="relationships"
          :display-items="displayItems"
          :entity-ref="entityRef"
          @select="onSelect"
        />
        <AttributesPane
          v-else-if="activeTab === 'attributes'"
          key="attributes"
          :attributes="entity.attributes"
          :gauges="entity.gauges"
          :entity-ref="entityRef"
        />
        <InventoryPane
          v-else
          key="inventory"
          :containers="entity.containers"
          :protagonist-ref="protagonistRef"
        />
      </Transition>
    </div>
  </div>
</template>

<style scoped>
.detail-column {
  min-width: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  height: 100%;
}
.card-toolbar {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 16px;
  border-bottom: 1px solid var(--line);
}
.card-title-block {
  padding-bottom: 12px;
}
.card-kicker {
  font-family: var(--font-mono);
  font-size: 0.62rem;
  letter-spacing: 0.08em;
  color: var(--prose-faint);
  margin-bottom: 4px;
}
.card-title {
  font-family: var(--font-display);
  font-size: 1.25rem;
  color: var(--ember-bright);
  letter-spacing: 0.06em;
}
.tabs {
  display: flex;
  gap: 0;
  align-self: stretch;
}
.tab {
  background: transparent;
  border: none;
  color: var(--prose-muted);
  font-family: var(--font-mono);
  font-size: 0.75rem;
  letter-spacing: 0.08em;
  padding: 14px 20px 12px;
  cursor: pointer;
  position: relative;
  transition: color 0.2s;
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
}
.tab:hover {
  color: var(--prose);
}
.tab.active {
  color: var(--ember-bright);
  border-bottom-color: var(--ember);
}
.tab-content {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding-top: 22px;
  scrollbar-width: none;
  -ms-overflow-style: none;
}
.tab-content::-webkit-scrollbar {
  display: none;
}
.detail-pane-enter-active {
  transition: opacity 220ms cubic-bezier(0.22, 1, 0.36, 1), transform 220ms cubic-bezier(0.22, 1, 0.36, 1);
}
.detail-pane-leave-active {
  transition: opacity 120ms ease, transform 120ms ease;
}
.detail-pane-enter-from {
  opacity: 0;
  transform: translateX(10px);
}
.detail-pane-leave-to {
  opacity: 0;
  transform: translateX(-6px);
}
@media (prefers-reduced-motion: reduce) {
  .detail-pane-enter-active,
  .detail-pane-leave-active {
    transition: none;
  }
}
</style>
